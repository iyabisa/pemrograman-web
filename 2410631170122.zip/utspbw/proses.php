<?php
define("PAJAK", 0.15);
$nama    = $_POST['nama'];
$nim     = $_POST['nim'];
$email   = $_POST['email'];
$layanan = $_POST['layanan'];
$barang_dipilih = isset($_POST['barang']) ? $_POST['barang'] : [];
$harga_list = [
    "Buku"   => 5000,
    "Pulpen" => 3000,
    "Pensil" => 2000
];

$subtotal = 0;
$detail_belanja = "";

if (!empty($barang_dipilih)) {
    foreach ($barang_dipilih as $item) {
        $qty = $_POST['qty_' . $item];
        $harga_item = $harga_list[$item] * $qty;
        $subtotal += $harga_item;
        $detail_belanja .= "$item ($qty pcs), ";
    }
}

// 5. Percabangan Biaya Layanan
if ($layanan == "Prioritas") {
    $biaya_layanan = 5000;
} else {
    $biaya_layanan = 0;
}
$total_pajak = $subtotal * PAJAK;
$total_akhir = $subtotal + $total_pajak + $biaya_layanan;

?>

<!DOCTYPE html>
<html>
<head>
    <title>Hasil Transaksi</title>
    <style>
        table { width: 60%; border-collapse: collapse; margin: 20px auto; background: white; }
        table, th, td { border: 1px solid black; padding: 10px; text-align: left; }
        th { background: #eee; }
        .status-error { color: red; text-align: center; font-weight: bold; }
    </style>
</head>
<body>
    <h2 style="text-align:center;">Ringkasan Pendaftaran Belanja</h2>
    
    <?php if (empty($barang_dipilih)): ?>
        <p class="status-error">Pesan: Anda belum memilih barang apapun!</p>
    <?php else: ?>
        <table>
            <tr><th>Nama / NIM</th><td><?= $nama ?> / <?= $nim ?></td></tr>
            <tr><th>Email</th><td><?= $email ?></td></tr>
            <tr><th>Item Dibeli</th><td><?= rtrim($detail_belanja, ", ") ?></td></tr>
            <tr><th>Subtotal</th><td>Rp <?= number_format($subtotal) ?></td></tr>
            <tr><th>Pajak (15%)</th><td>Rp <?= number_format($total_pajak) ?></td></tr>
            <tr><th>Biaya Layanan (<?= $layanan ?>)</th><td>Rp <?= number_format($biaya_layanan) ?></td></tr>
            <tr><th><strong>Total Akhir</strong></th><td><strong>Rp <?= number_format($total_akhir) ?></strong></td></tr>
        </table>
    <?php endif; ?>

    <p style="text-align:center;"><a href="pendaftaran.html">Kembali ke Form</a></p>
</body>
</html>
